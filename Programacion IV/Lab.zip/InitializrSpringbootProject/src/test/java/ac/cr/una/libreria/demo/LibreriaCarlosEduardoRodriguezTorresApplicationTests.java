package ac.cr.una.libreria.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibreriaCarlosEduardoRodriguezTorresApplicationTests {

	@Test
	void contextLoads() {
	}

}
