/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ac.cr.una.libreria.data;

/**
 *
 * @author cuent
 */
import ac.cr.una.libreria.data.BaseData;
import ac.cr.una.libreria.model.Editorial;
import ac.cr.una.libreria.model.Libro;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
 
/**
 * Capa de datos para Libro.
 * Usa procedimientos almacenados con CallableStatement.
 */
public class LibroData extends BaseData {
 
    /**
     * Retorna libros filtrados por el id de la editorial.
     */
    public LinkedList<Libro> getLibros(int codEditorial) {
        LinkedList<Libro> lista = new LinkedList<>();
 
        try {
            Connection conexion = this.conectar();
            String query = "CALL LibreriaEstudiante.list_libros_por_editorial(?);";
            CallableStatement stmt = conexion.prepareCall(query);
            stmt.setInt(1, codEditorial);
            ResultSet result = stmt.executeQuery();
 
            while (result.next()) {
                Libro libro = new Libro();
                libro.setIdLibro(result.getInt(1));
                libro.setTitulo(result.getString(2));
                libro.setAno(result.getInt(3));
                libro.setPrecio(result.getFloat(5));
 
                // Editorial simple para mostrar en la vista
                Editorial e = new Editorial();
                e.setIdEditorial(result.getInt(4));
                libro.setEditorial(e);
 
                lista.add(libro);
            }
 
            result.close();
            stmt.close();
            conexion.close();
 
        } catch (SQLException ex) {
            System.out.println("LibroData.getLibros: " + ex.getMessage());
        }
 
        return lista;
    }
 
    /**
     * Inserta un libro nuevo llamando al procedimiento almacenado.
     */
    public boolean addLibro(Libro libro) {
        boolean resultado = false;
 
        try {
            Connection conexion = this.conectar();
            String query = "CALL LibreriaEstudiante.add_libro(?, ?, ?, ?);";
            CallableStatement stmt = conexion.prepareCall(query);
            stmt.setString(1, libro.getTitulo());
            stmt.setInt(2, libro.getAno());
            stmt.setInt(3, libro.getEditorial().getIdEditorial());
            stmt.setFloat(4, libro.getPrecio());
            stmt.executeQuery();
            resultado = true;
 
            stmt.close();
            conexion.close();
 
        } catch (SQLException ex) {
            System.out.println("LibroData.addLibro: " + ex.getMessage());
        }
 
        return resultado;
    }
}