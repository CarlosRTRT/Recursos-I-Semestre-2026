/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ac.cr.una.libreria.model;

/**
 *
 * @author cuent
 */
public class Editorial {
 
    private int    idEditorial;
    private String nombre;
    private String direccion;
    private String telefono;
 
    public Editorial() {}
 
    public Editorial(int idEditorial, String nombre, String direccion, String telefono) {
        this.idEditorial = idEditorial;
        this.nombre      = nombre;
        this.direccion   = direccion;
        this.telefono    = telefono;
    }
 
    // Getters y Setters
    public int getIdEditorial()                  { return idEditorial; }
    public void setIdEditorial(int idEditorial)  { this.idEditorial = idEditorial; }
 
    public String getNombre()                    { return nombre; }
    public void setNombre(String nombre)         { this.nombre = nombre; }
 
    public String getDireccion()                 { return direccion; }
    public void setDireccion(String direccion)   { this.direccion = direccion; }
 
    public String getTelefono()                  { return telefono; }
    public void setTelefono(String telefono)     { this.telefono = telefono; }
 
    @Override
    public String toString() {
        return "Editorial{id=" + idEditorial + ", nombre=" + nombre + "}";
    }
}
 