package ac.cr.una.libreria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = "cr.ac.una.libreria")
public class LibreriaCarlosEduardoRodriguezTorresApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibreriaCarlosEduardoRodriguezTorresApplication.class, args);
	}

}
