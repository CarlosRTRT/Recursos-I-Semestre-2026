/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ac.cr.una.libreria.model;

/**
 *
 * @author cuent
 */
public class Libro {
 
    private int      idLibro;
    private String   titulo;
    private int      ano;
    private float    precio;
    private Editorial editorial;  // relación con Editorial
 
    public Libro() {}
 
    public Libro(int idLibro, String titulo, int ano, float precio, Editorial editorial) {
        this.idLibro    = idLibro;
        this.titulo     = titulo;
        this.ano        = ano;
        this.precio     = precio;
        this.editorial  = editorial;
    }
 
    // Getters y Setters
    public int getIdLibro()                      { return idLibro; }
    public void setIdLibro(int idLibro)          { this.idLibro = idLibro; }
 
    public String getTitulo()                    { return titulo; }
    public void setTitulo(String titulo)         { this.titulo = titulo; }
 
    public int getAno()                          { return ano; }
    public void setAno(int ano)                  { this.ano = ano; }
 
    public float getPrecio()                     { return precio; }
    public void setPrecio(float precio)          { this.precio = precio; }
 
    public Editorial getEditorial()              { return editorial; }
    public void setEditorial(Editorial editorial){ this.editorial = editorial; }
 
    @Override
    public String toString() {
        return "Libro{id=" + idLibro + ", titulo=" + titulo + ", ano=" + ano + "}";
    }
}