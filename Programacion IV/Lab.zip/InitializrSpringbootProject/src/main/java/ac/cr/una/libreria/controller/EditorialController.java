/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/springframework/Controller.java to edit this template
 */
package ac.cr.una.libreria.controller;

import ac.cr.una.libreria.data.EditorialData;
import ac.cr.una.libreria.data.LibroData;
import ac.cr.una.libreria.model.Editorial;
import ac.cr.una.libreria.model.Libro;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 *
 * @author cuent
 */
import java.util.LinkedList;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
 
@Controller
@RequestMapping("/editorial")
public class EditorialController {
 
    LinkedList<Editorial> editoriales;
    EditorialData editorialData;
    LibroData libroData;
 
    public EditorialController() {
        editorialData = new EditorialData();
        libroData     = new LibroData();
    }
 
    @GetMapping("/iniciar")
    public String iniciar(Model model) {
        editoriales = editorialData.getEditoriales();
        model.addAttribute("editoriales", editoriales);
        return "libros_por_editorial";
    }
 
    @GetMapping("/mostrar")
    public String mostrar(@RequestParam int codEditorial, Model model) {
        // Buscar la editorial seleccionada
        editoriales = editorialData.getEditoriales();
        Editorial editorialSeleccionada = null;
        for (Editorial e : editoriales) {
            if (e.getIdEditorial() == codEditorial) {
                editorialSeleccionada = e;
                break;
            }
        }
 
        LinkedList<Libro> libros = libroData.getLibros(codEditorial);
 
        model.addAttribute("editorial",   editorialSeleccionada);
        model.addAttribute("libros",      libros);
        model.addAttribute("editoriales", editoriales); // para el combobox de insertar
        return "mostrar_libros_por_editorial";
    }
 
    @PostMapping("/insertar")
    public String insertar(@RequestParam String titulo,
                           @RequestParam int    ano,
                           @RequestParam int    idEditorial,
                           @RequestParam float  precio) {
 
        Libro libro = new Libro();
        libro.setTitulo(titulo);
        libro.setAno(ano);
        libro.setPrecio(precio);
 
        Editorial e = new Editorial();
        e.setIdEditorial(idEditorial);
        libro.setEditorial(e);
 
        libroData.addLibro(libro);
 
        return "redirect:/editorial/mostrar?codEditorial=" + idEditorial;
    }
}
