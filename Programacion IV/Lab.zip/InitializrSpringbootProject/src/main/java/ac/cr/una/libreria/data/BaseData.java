/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ac.cr.una.libreria.data;

/**
 *
 * @author cuent
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
 
/**
 * Clase base para la capa de datos.
 * Provee el método conectar() que retorna una conexión a la BD.
 */
public class BaseData {
 
    private static final String DATABASE = "LibreriaEstudiante";
    private static final String USER     = "root";
    private static final String PASS     = "";
    private static final String HOST     = "localhost";
    private static final int    PORT     = 3306;
    private static final String URL      = "jdbc:mysql://" + HOST + ":" + PORT + "/" + DATABASE;
 
    public static Connection conectar() {
        Connection conexion = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.out.println("Driver no encontrado: " + e.getMessage());
        }
        try {
            conexion = DriverManager.getConnection(URL, USER, PASS);
            System.out.println("Conexión establecida con: " + DATABASE);
        } catch (SQLException e) {
            System.out.println("Error de conexión: " + e.getMessage());
        }
        return conexion;
    }
}