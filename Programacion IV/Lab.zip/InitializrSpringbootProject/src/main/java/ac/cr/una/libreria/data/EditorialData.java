/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ac.cr.una.libreria.data;

/**
 *
 * @author cuent
 */

import ac.cr.una.libreria.data.BaseData;
import ac.cr.una.libreria.model.Editorial;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
 

public class EditorialData extends BaseData {
 
    /**
     * Retorna la lista de todas las editoriales.
     */
    public LinkedList<Editorial> getEditoriales() {
        LinkedList<Editorial> lista = new LinkedList<>();
 
        try {
            Connection conexion = this.conectar();
            String query = "CALL LibreriaEstudiante.list_editoriales();";
            CallableStatement stmt = conexion.prepareCall(query);
            ResultSet result = stmt.executeQuery();
 
            while (result.next()) {
                Editorial e = new Editorial();
                e.setIdEditorial(result.getInt(1));
                e.setNombre(result.getString(2));
                e.setDireccion(result.getString(3));
                e.setTelefono(result.getString(4));
                lista.add(e);
            }
 
            result.close();
            stmt.close();
            conexion.close();
 
        } catch (SQLException ex) {
            System.out.println("EditorialData.getEditoriales: " + ex.getMessage());
        }
 
        return lista;
    }
}
 
 